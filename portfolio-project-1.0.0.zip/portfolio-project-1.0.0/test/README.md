# Test Folder

This README exists, so the folder shows up in source control like git. This
file is not needed and can be safely deleted. 

However, for completeness, this folder exists for storing JUnit test files.
Test folders can be much less structured than source folders, but I would
generally recommend following the same directory structure as the source folder.
In other words, include the package paths, such as 
`components/naturalnumber/...`.
